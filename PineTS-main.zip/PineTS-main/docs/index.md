---
layout: home
title: Home
nav_order: 1
permalink: /
---

# PineTS

PineTS is a TypeScript implementation of the Pine Script language, allowing you to write trading indicators and strategies using TypeScript while leveraging the power of Pine Script's execution model and functions.

With PineTS, you can create, test and visualize technical indicators using modern web technologies while maintaining compatibility with the Pine Script language features.

<div class="cta-container" style="text-align: center; margin: 2rem 0;">
  <a href="getting-started/" class="btn btn-primary fs-5 mb-4 mb-md-0 mr-2">Get Started →</a>
  <a href="https://github.com/LuxAlgo/PineTS" class="btn btn-outline fs-5 mb-4 mb-md-0">View on GitHub</a>
</div>

---

## Documentation

### [Getting Started](getting-started.md)

Learn the basics of converting Pine Script to PineTS and understand key differences.

### [Initialization and Usage](initialization-and-usage.md)

Complete guide on how to initialize PineTS and run indicators with detailed API documentation, including all constructor parameters, run method options, and return value formats.

### [Syntax Guide](syntax-guide.md)

Detailed guide on PineTS syntax and how to write code equivalent to Pine Script, including variable declarations (`var` vs `let`), series access, and control structures.

### [Language Coverage](lang-coverage.md)

Click here to [explore](lang-coverage.md) the [Pine Script language](lang-coverage.md) features implemented in PineTS, including execution model, time series, and more.

### [API Coverage](api-coverage.md)

Click [here](api-coverage.md) to check the implementation status of [Pine Script API](api-coverage.md) functions and methods in PineTS.

---

Created by [Alaa-eddine KADDOURI](https://github.com/alaa-eddine) | Licensed under AGPL-3.0
