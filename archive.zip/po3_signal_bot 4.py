#!/usr/bin/env python3
"""
PO3 Signal Bot — Binance Spot | 4H | Accumulation → Manipulation
Single-file, production-ready, lightweight 24/7 signal scanner.

Strategy: ICT Power of 3 (simplified)
  1) Accumulation  — sideways range, 50+ candles, strict filters
  2) Manipulation  — last 4H candle breaks range high or low

Data source: https://data-api.binance.vision  (public, no API key)
Alerts via:  Telegram Bot API
"""

import requests
import time
import sys

# ─────────────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────────────
BASE_URL        = "https://data-api.binance.vision"
TG_TOKEN        = "8776695041:AAGhYc-SDcrm6CrrPXGsmJf0netTfBhcio8"
TG_CHAT         = "127278288"

INTERVAL        = "4h"          # timeframe
MIN_CANDLES     = 50            # minimum accumulation candles
KLINE_LIMIT     = 260           # candles to fetch per symbol
CYCLE_SLEEP     = 60            # seconds between full scan cycles
HTTP_TIMEOUT    = 12            # request timeout in seconds
MIN_24H_VOL     = 1_000_000    # min 24h USDT quote volume to qualify

# Stablecoins — fully excluded
STABLECOINS = frozenset({
    "USDT", "USDC", "BUSD", "DAI", "TUSD", "USDP", "FDUSD", "PYUSD",
    "UST",  "USDD", "FRAX", "LUSD", "BIDR", "VAI",  "XUSD", "USDJ",
    "USDS", "SUSD", "AEUR",
})

# ── Accumulation filters (internal — NOT shown in Telegram) ──────
MAX_SLOPE_PCT   = 1.2           # total drift % over the range
MIN_WIDTH_PCT   = 1.0           # range width % of midpoint
MAX_WIDTH_PCT   = 12.0          # range width % of midpoint
GROW_WIDTH_PCT  = 15.0          # threshold to stop growing window
TOUCH_ZONE_PCT  = 0.05          # 5 % of range width = "touch zone"
MIN_TOUCHES     = 3             # minimum touches per boundary

# ─────────────────────────────────────────────────────────────────────
# RUNTIME STATE
# ─────────────────────────────────────────────────────────────────────
# Dedup cache: (symbol, direction, candle_open_time) → timestamp
_sig_cache  = {}
_CACHE_TTL  = 86400             # 24 hours

# Symbol list cache (refreshed hourly)
_sym_list   = []
_sym_ts     = 0.0
_SYM_TTL    = 3600              # 1 hour

# ─────────────────────────────────────────────────────────────────────
# HTTP SESSION — connection-pooled, keep-alive
# ─────────────────────────────────────────────────────────────────────
_http = requests.Session()
_http.headers["User-Agent"] = "PO3SignalBot/1.0"
_http.headers["Connection"] = "keep-alive"

# ─────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────

def _fmt_price(price):
    """Format price with appropriate decimal precision."""
    if price >= 1000:
        return f"{price:.2f}"
    if price >= 1:
        return f"{price:.4f}"
    if price >= 0.01:
        return f"{price:.6f}"
    return f"{price:.8f}"


def _lin_slope(vals):
    """Linear-regression slope (no numpy needed)."""
    n = len(vals)
    if n < 2:
        return 0.0
    xm = (n - 1) / 2.0
    ym = sum(vals) / n
    num = den = 0.0
    for i, y in enumerate(vals):
        d = i - xm
        num += d * (y - ym)
        den += d * d
    return num / den if den else 0.0


# ─────────────────────────────────────────────────────────────────────
# BINANCE API
# ─────────────────────────────────────────────────────────────────────

def _fetch_symbols():
    """
    Return sorted list of active USDT spot pairs that:
      - are TRADING status
      - allow spot trading
      - base asset is NOT a stablecoin
      - 24 h USDT quote volume >= MIN_24H_VOL
    Result is cached for 1 hour.
    """
    global _sym_list, _sym_ts
    now = time.time()
    if _sym_list and now - _sym_ts < _SYM_TTL:
        return _sym_list

    # 1) Eligible symbols from exchangeInfo
    try:
        r = _http.get(f"{BASE_URL}/api/v3/exchangeInfo", timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        eligible = set()
        for s in r.json()["symbols"]:
            if (s["quoteAsset"] == "USDT"
                    and s["status"] == "TRADING"
                    and s.get("isSpotTradingAllowed", True)
                    and s["baseAsset"] not in STABLECOINS):
                eligible.add(s["symbol"])
    except Exception:
        return _sym_list                       # fallback to stale cache

    # 2) Volume gate — single call returns all tickers
    try:
        r = _http.get(f"{BASE_URL}/api/v3/ticker/24hr", timeout=25)
        r.raise_for_status()
        vol = {}
        for t in r.json():
            try:
                vol[t["symbol"]] = float(t["quoteVolume"])
            except (KeyError, ValueError):
                pass
        result = sorted(s for s in eligible if vol.get(s, 0) >= MIN_24H_VOL)
    except Exception:
        result = sorted(eligible)              # best-effort without volume

    _sym_list = result
    _sym_ts   = now
    return result


def _klines(symbol):
    """Fetch 4H klines; return raw list or None on failure / too short."""
    try:
        r = _http.get(
            f"{BASE_URL}/api/v3/klines",
            params={"symbol": symbol, "interval": INTERVAL, "limit": KLINE_LIMIT},
            timeout=HTTP_TIMEOUT,
        )
        r.raise_for_status()
        data = r.json()
        return data if len(data) >= MIN_CANDLES + 2 else None
    except Exception:
        return None


# ─────────────────────────────────────────────────────────────────────
# ACCUMULATION DETECTOR
# ─────────────────────────────────────────────────────────────────────

def _find_accum(candles):
    """
    Detect a sideways accumulation range in the given candles.

    Algorithm
    ---------
    1. Start from the most recent candle and grow the window backwards.
    2. Stop as soon as the combined range exceeds GROW_WIDTH_PCT (15 %)
       — this means we've entered a trending zone.
    3. Apply strict validation filters on the resulting window:
       • Width  : between MIN_WIDTH_PCT and MAX_WIDTH_PCT
       • Slope  : total price drift < MAX_SLOPE_PCT
       • Touches: logical touches at upper & lower boundaries

    Parameters
    ----------
    candles : list of kline arrays (EXCLUDING the manipulation candle)

    Returns
    -------
    dict with keys  rh, rl, cnt   or  None
    """
    n = len(candles)
    if n < MIN_CANDLES:
        return None

    # ── Phase 1: grow window from the end ───────────────────────
    rh = float(candles[-1][2])
    rl = float(candles[-1][3])
    cnt = 1

    for i in range(n - 2, -1, -1):
        nh = max(rh, float(candles[i][2]))
        nl = min(rl, float(candles[i][3]))
        mid = (nh + nl) / 2.0
        if mid <= 0:
            break
        if (nh - nl) / mid * 100.0 > GROW_WIDTH_PCT:
            break
        rh, rl, cnt = nh, nl, cnt + 1

    if cnt < MIN_CANDLES:
        return None

    # ── Phase 2: validate ───────────────────────────────────────
    rw  = rh - rl
    mid = (rh + rl) / 2.0
    if mid <= 0 or rw <= 0:
        return None

    # Width filter
    wp = rw / mid * 100.0
    if wp < MIN_WIDTH_PCT or wp > MAX_WIDTH_PCT:
        return None

    # Slope filter — total drift as % of midpoint
    closes = [float(c[4]) for c in candles[-cnt:]]
    sp = abs(_lin_slope(closes) * cnt / mid * 100.0)
    if sp > MAX_SLOPE_PCT:
        return None

    # Touch filter — must have logical repetition at both boundaries
    tz = rw * TOUCH_ZONE_PCT
    ut = sum(1 for c in candles[-cnt:] if float(c[2]) >= rh - tz)
    lt = sum(1 for c in candles[-cnt:] if float(c[3]) <= rl + tz)
    need = max(MIN_TOUCHES, cnt // 25)
    if ut < need or lt < need:
        return None

    return {"rh": rh, "rl": rl, "cnt": cnt}


# ─────────────────────────────────────────────────────────────────────
# MANIPULATION DETECTOR
# ─────────────────────────────────────────────────────────────────────

def _check_manip(last_candle, rh, rl):
    """
    Check if the LAST 4H candle breaks the accumulation range.
    Returns 'UP' or 'DOWN' or None.

    If the candle breaks both sides (extreme volatility),
    the direction with the larger breakout wins.
    """
    lh = float(last_candle[2])          # last candle high
    ll = float(last_candle[3])          # last candle low

    up_break   = lh - rh               # positive → broke above
    down_break = rl - ll               # positive → broke below

    if up_break > 0 and down_break > 0:
        return "UP" if up_break >= down_break else "DOWN"
    if up_break > 0:
        return "UP"
    if down_break > 0:
        return "DOWN"
    return None


# ─────────────────────────────────────────────────────────────────────
# TELEGRAM
# ─────────────────────────────────────────────────────────────────────

def _tg_send(text):
    """Send a text message to Telegram. Returns True on success."""
    try:
        r = _http.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT, "text": text},
            timeout=HTTP_TIMEOUT,
        )
        return r.status_code == 200
    except Exception:
        return False


def _build_msg(sym, direction, price, rh, rl, cnt, exceed_pct):
    """Build the Telegram signal message (Arabic format as specified)."""
    phase = "#ManipulationUp" if direction == "UP" else "#ManipulationDown"
    return (
        f"✅ العملة: #{sym}\n"
        f"📍 المرحلة: {phase}\n"
        f"⏰ الفريم: #4H\n"
        f"💰 الحالي: {_fmt_price(price)}\n"
        f"⬆️ الحد العلوي: {_fmt_price(rh)}\n"
        f"⬇️ الحد السفلي: {_fmt_price(rl)}\n"
        f"📦 عدد الشموع: {cnt}\n"
        f"📍 نسبة التجاوز: {exceed_pct:.2f}%"
    )


# ─────────────────────────────────────────────────────────────────────
# DEDUPLICATION CACHE
# ─────────────────────────────────────────────────────────────────────

def _clean_cache():
    """Evict expired entries from the signal dedup cache."""
    now = time.time()
    stale = [k for k, v in _sig_cache.items() if now - v > _CACHE_TTL]
    for k in stale:
        del _sig_cache[k]


def _is_dup(symbol, direction, open_time):
    """Return True if this exact signal was already sent."""
    key = (symbol, direction, open_time)
    if key in _sig_cache:
        return True
    _sig_cache[key] = time.time()
    return False


# ─────────────────────────────────────────────────────────────────────
# SCAN CYCLE
# ─────────────────────────────────────────────────────────────────────

def _run_cycle(cycle_num):
    """
    One complete scan cycle:
      1. Fetch symbol list (cached)
      2. For each symbol: fetch klines → detect accumulation → check manipulation
      3. Send Telegram alerts for new signals
      4. Print minimal terminal output
    """
    symbols = _fetch_symbols()
    total = len(symbols)
    print(f"[START] cycle {cycle_num} - scanning {total} symbols")

    sent = 0
    _clean_cache()

    for sym in symbols:
        try:
            kl = _klines(sym)
            if kl is None:
                continue

            # Last candle  = manipulation candidate
            # Previous ones = accumulation data
            acc = _find_accum(kl[:-1])
            if acc is None:
                continue

            d = _check_manip(kl[-1], acc["rh"], acc["rl"])
            if d is None:
                continue

            # Dedup — one signal per (symbol, direction, candle)
            open_time = kl[-1][0]
            if _is_dup(sym, d, open_time):
                continue

            # Exceed percentage
            if d == "UP":
                ep = (float(kl[-1][2]) - acc["rh"]) / acc["rh"] * 100.0
            else:
                ep = (acc["rl"] - float(kl[-1][3])) / acc["rl"] * 100.0
            ep = max(ep, 0.0)

            price = float(kl[-1][4])
            msg = _build_msg(sym, d, price, acc["rh"], acc["rl"], acc["cnt"], ep)

            if _tg_send(msg):
                print(f"[SENT] {sym}")
                sent += 1
                time.sleep(0.5)              # Telegram rate-limit safety

        except Exception:
            continue

    print(f"[END] cycle {cycle_num} - sent {sent} signals")
    return sent


# ─────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────

def main():
    cycle = 1
    while True:
        try:
            _run_cycle(cycle)
        except KeyboardInterrupt:
            print("\n[STOP] Bot stopped by user.")
            sys.exit(0)
        except Exception as e:
            print(f"[ERROR] {e}")

        print(f"[WAIT] sleeping {CYCLE_SLEEP} seconds...")
        time.sleep(CYCLE_SLEEP)
        cycle += 1


if __name__ == "__main__":
    main()
